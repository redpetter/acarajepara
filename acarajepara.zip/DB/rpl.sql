-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2016 at 03:07 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `rpl`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
`id` int(11) NOT NULL,
  `alamat` text NOT NULL,
  `kota` varchar(20) NOT NULL,
  `no_hp` varchar(12) NOT NULL,
  `no_tlp` varchar(12) NOT NULL,
  `email` varchar(30) NOT NULL,
  `content` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `alamat`, `kota`, `no_hp`, `no_tlp`, `email`, `content`) VALUES
(1, '<p>Jalan Taman Siswa</p>\r\n<p>Rt 3 Rw 3</p>\r\n<p>Tahunan Jepara</p>\r\n<p> Kecamatan Tahunan </p>\r\n<p> Kabupaten Jepara </p>', 'Jepara', '085351277477', '--', 'linbub007@gmail.com', '<p> Jasa informasi untuk user mengetahui informasi tentang jepara begitu juga Anda dapat membooking yang tersedia </p>');

-- --------------------------------------------------------

--
-- Table structure for table `komentar`
--

CREATE TABLE IF NOT EXISTS `komentar` (
`id_komentar` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `komentar` text NOT NULL,
  `waktu` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `komentar`
--

INSERT INTO `komentar` (`id_komentar`, `nama`, `komentar`, `waktu`) VALUES
(1, 'Andis', 'Keren bro lanjutkan berkarya', '2016-10-01 00:00:00'),
(2, 'Kafidzin', 'Amazing, Simple dan menarik', '2016-10-05 00:00:00'),
(3, 'Fahmi', 'Di tambah kan info sekitar jepara kalo bisa hehehe', '2016-10-14 01:26:00'),
(4, 'Mahbub', 'Website ini Membantu sekali', '2016-10-15 01:43:00'),
(5, 'Hery', 'ini baru keren acara di jepra di infokan secara udate', '2016-10-17 10:21:32'),
(6, 'Risa', 'Meriahkan website dengan mengshare di medsos yuk', '2016-10-18 13:25:14'),
(7, 'Vira', 'Ini baru membangun Jepara', '2016-10-20 16:23:28'),
(8, 'Dedi', 'apik', '2016-11-11 11:34:32');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` bigint(20) NOT NULL,
  `nama` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `nama`, `email`, `password`) VALUES
(0, 'Aliando', 'ali@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `setup_about`
--

CREATE TABLE IF NOT EXISTS `setup_about` (
`id_about` int(11) NOT NULL,
  `kat_about` varchar(30) NOT NULL,
  `judul_about` varchar(50) NOT NULL,
  `konten_about` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `setup_about`
--

INSERT INTO `setup_about` (`id_about`, `kat_about`, `judul_about`, `konten_about`) VALUES
(2, 'Profil', 'About Website', '<p> Website ini bertujuan untuk mempermudah Anda menegtahui informasi dari event di jepara,bola beserta wisata. </p>'),
(7, 'pembayaran', 'Cara Pembayaran', '<p>Caraa pembayaran ada 2 alternatif yang bisa dipilih. Pertama anda bisa melakukan pembayaran langsung ke kantor kami atau dengan cara kedua bisa melakukan transfer melalui nomor rekening kami yang tersedia. Dengan ketentuan sebagai berikut :</p>\r\n<ol>\r\n<li>Pembayaran Langsung\r\n<ul>\r\n<li>Pembayaran langung dikhususkan untuk pelanggan yang berada dekat dengan kantor kami.</li>\r\n<li>Pembayaran dilakukan 5 hari sebelum keberangkatan.</li>\r\n<li>Syarat pembayaran harus melampirkan Invoice dan Tiket yang telah di booking.</li>\r\n<li>Pembayaran akan dilayani di jam kerja.</li>\r\n</ul>\r\n</li>\r\n<li>Pembayaran via Transfer\r\n<ul>\r\n<li>Pembayaran ini dimaksudkan untuk pelanggan yang dari luar kota maunpun yang menginginkan proses praktis.</li>\r\n<li>Pembayaran selambat-lambatnya harus telah diterima oleh kami 5 hari sebelum hari keberangkatan tour.</li>\r\n<li>Transfer dapat dilakukan ke nomor rekening berikut :\r\n<ul>\r\n<li>BCA : 3120618040&nbsp;a/n Nini Gumaneri</li>\r\n<li>Mandiri : 1110005416478 a/n&nbsp;Nini Gumaneri</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n</li>\r\n</ol>'),
(8, 'syarat', '', '<p>Syarat dan Ketentuan ini berguna untuk membantu anda dalam melakukan pembookingan sesuai dengan ketentuan-ketentuan yang telah kami buat. Sehingga anda nantinya tidak merasa rugi dan salah dalam memilih paket ataupun penginapan nantinya. Seilahkan cermati ketentuan-ketentuan yang telah dibuat dan lanjutkan dengan melakukan pembookingan.</p>'),
(12, 'reservasi', '', '<ol>\r\n<li>Sebelum melakukan pembookingan pastikan anda&nbsp;<a href="formRegistrasi.php">Login</a>&nbsp;terlebih dulu ke website ini.</li>\r\n<li>Jika belum memiliki akun, makan diperkenankan anda untuk malakukan&nbsp;<a href="formRegistrasi.php">Regirtrasi</a></li>\r\n<li>Setelah melakukan Login, lengkapi Profil anda jika memang Profil anda masih belum dilengkapi</li>\r\n<li>Seletah melengkapi Profil anda, lakukan pembookingan pada menu Booking.</li>\r\n<li>Lalu Pilih Paket sesuai dengan yang anda inginkan.</li>\r\n<li>Jika anda memilih untuk cara pembayaran secara Bayar diTempat, maka anda bisa langsung melakukan Cetak Tiket.</li>\r\n</ol>'),
(13, 'syarat', 'Ketentuan Kapasitas Hotel', '<p>Jumlah maksimal pengunjung per kamar:</p>\r\n<ul style="list-style-type: circle;">\r\n<li>Kelas Standar, mak. 2 orang</li>\r\n<li>Kelas Superior, mak. 2 orang</li>\r\n<li>Kelas Delux, mak. 2/4 orang*</li>\r\n<li>Kelas Suit Keluarga, mak. 4 orang</li>\r\n</ul>\r\n<p>*ketentuan dapat berubah sewaktu-waktu</p>'),
(14, 'syarat', 'Ketentuan Memilih Penginapan', '<p>Untuk pembookingan diharapkan diteliti sebelum benar-benar malakukan booking, artinya :</p>\r\n<ul style="list-style-type: circle;">\r\n<li>Sesuaikan tempat penginapan dengan tempat anda akan berwisata.</li>\r\n<li>Jika anda memilih paket wisata yang dengan jenis One-Way, makan pada form pilih penginapan silahkan pilih option "Tidak Menginap".</li>\r\n<li>Agar lebih tepat memilih penginapan, maka lihat dahulu dimana paket wisata tersebut dimana tempatnya berada.</li>\r\n</ul>'),
(15, 'syarat', 'Ketentuan Pembookingan', '<ul style="list-style-type: circle;">\r\n<li>Perubahan Peket dan Penginapan silahkan hubungi contact person kami yang ada pada website, dan hanya bisa dilakukan 5 hari sebelum hari keberangkatan tour. Kurang dari itu perubahan tidak bisa dilakukan.</li>\r\n<li>Pembatalan booking dapat dilakukan 7 hari sebelum tanggal keberangkatan tour yang telah di booking. Biaya yang telah ditranfer akan dikembalikan dengan potongan 10% dari total biaya dan harus melakukan konfirmasi terlebih dahulu melalui contact person kami.</li>\r\n<li>Untuk biaya penginapan yang masih belum terbilang pada saat melakukan pembookingan, akan kami konfirmasikan ke Akun anda 7 hari sebelum hari keberangkatan tour. Dan dapat melakukan cetak tiket setelah hari itu.</li>\r\n</ul>');

-- --------------------------------------------------------

--
-- Table structure for table `setup_dasboard`
--

CREATE TABLE IF NOT EXISTS `setup_dasboard` (
`id_dasboard` int(11) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `konten` text NOT NULL,
  `gambar` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `setup_dasboard`
--

INSERT INTO `setup_dasboard` (`id_dasboard`, `nama`, `konten`, `gambar`) VALUES
(9, 'Jepara', '<p>Jepara di Juluki Kota Ukir\r\nKabupaten Jepara adalah salah satu kabupaten di Provinsi Jawa Tengah. Ibukotanya adalah Jepara. Kabupaten ini berbatasan dengan Laut Jawa di barat dan utara, Kabupaten Pati dan Kabupaten Kudus di timur, serta Kabupaten Demak di selatan. Wilayah Kabupaten Jepara juga meliputi Kepulauan Karimunjawa, yang berada di Laut Jawa.\r\nKabupaten Jepara terletak di pantura timur Jawa Tengah, dimana bagian barat dan utara dibatasi oleh laut. Bagian timur wilayah kabupaten ini merupakan daerah pegunungan.\r\n\r\nWilayah Kabupaten Jepara juga meliputi Kepulauan Karimunjawa, yakni gugusan pulau-pulau di Laut Jawa. Dua pulau terbesarnya adalah Pulau Karimunjawa dan Pulau Kemujan. Sebagian besar wilayah Karimunjawa dilindungi dalam Cagar Alam Laut Karimunjawa. Penyeberangan ke kepulauan ini dilayani oleh kapal ferry yang bertolak dari Pelabuhan Jepara. Karimunjawa juga terdapat Bandara Dewandaru yang didarati pesawat dari Bandara Ahmad Yani Semarang.\r\n</p>', 'jeparaa.jpg'),
(10, 'Caribbean van Java', '<p>Karimunjawa adalah sebuah kecamatan di Jepara, Jawa Tengah yang berbentuk kepulauan di tengah Laut Jawa. Berjarak sekitar 83 KM di utara kota Jepara, Kepulauan Karimunjawa terdiri dari 27 pulau, namun hanya 5 pulau yang berpenghuni. Potensi wisata utama dari Kepulauan Karimunjawa adalah keindahan lautnya. Karena potensi wisata taman laut tersebut, kepulauan ini ditetapkan sebagai salah satu taman nasional Indonesia pada tahun 2001.Karimunjawa adalah sebuah kecamatan di Jepara, Jawa Tengah yang berbentuk kepulauan di tengah Laut Jawa. Berjarak sekitar 83 KM di utara kota Jepara, Kepulauan Karimunjawa terdiri dari 27 pulau, namun hanya 5 pulau yang berpenghuni. Potensi wisata utama dari Kepulauan Karimunjawa adalah keindahan lautnya. Karena potensi wisata taman laut tersebut, kepulauan ini ditetapkan sebagai salah satu taman nasional Indonesia pada tahun 2001.</p>', 'karimun.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `setup_jepara`
--

CREATE TABLE IF NOT EXISTS `setup_jepara` (
`id_jepara` int(11) NOT NULL,
  `kat_jepara` varchar(30) NOT NULL,
  `judul_jepara` varchar(50) NOT NULL,
  `konten_jepara` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `setup_jepara`
--

INSERT INTO `setup_jepara` (`id_jepara`, `kat_jepara`, `judul_jepara`, `konten_jepara`) VALUES
(5, 'Profil', '', '<p style="text-align: justify;"><strong>JEPARA</strong> adalah salah satu pulau di Indonesia yang terletak di provinsi Jawa Tengah atau pulau Jawa.</p>\r\n<p style="text-align: justify;"> Di jepara juga terkenal dengan sebuta kota ukir yang familiar</p>'),
(6, 'profil', 'Cerita Jepara', '<p style="text-align: justify;"> Jepara yang diapit dengan Kota Kudus den demak  tidak membuat kota jepara terpelosok justru banyak wistawan yang datang dan mampir menikmati pantai dan taman yang berada di jepara </p>\r\n<p style="text-align: justify;">Seperti daerah lainnya di Indonesia, iklim Jepara secara umum bersifat tropis dengan suhu udara yang cukup tinggi, yaitu antara 22,6&deg;C sampai 31,5&deg;C.</p>\r\n<p style="text-align: justify;">Terdapat 1 gunung penghubung antara jepara dengan demak</p>\r\n<p style="text-align: justify;">\r\nGunung Muria ini dahulunya adalah kawasan ,tetapi lambat laun gunung ini di lokasikan di kudus mungkin karena lebih dekat dengan kudus. </p>\r\n<p style="text-align: justify;">\r\nWalaupun Jepara ini kecil tapi tingkat kehidupan nya makmur,sejahterra.</p>'),
(7, 'sejarah', '', '<p>Jepara dahulunya adalah pulau tersendiri yang mempunyai selat penghubung kudus dan demak, konon selat ini menghilang secara misterius dan menggabungkan jepara, kudus,demak.</p> <p style="text-align: justify;">\r\nDan kerajaan tertua berada di jepara dengan istilah kerajaan Ratu Shima yang letak nya kono di daerah Keling,</p> <p style="text-align: justify;">Setelah itu terdaat cerita R.Sultan Hadirin dan juga Ratu kalinyamat.</p>\r\n<p style="text-align: justify;">Banyak orang mencari fosil fosil kerajaan tua ini namun sangat sulit untuk menemukan benda bersejarah ini.\r\n</p>\r\n<p style="text-align: justify;">Dulu Jepara mempunyai Pelabuhan yang berada di Dermaga Pantai Kartini. Dermaga ini di buat oleh Ratu Kalinyamat.</p>\r\n<p style="text-align: justify;">Enggak hanya Mempunyai Kerajaan Tua, jepara juga Mempunyai wanita legendaris yaitu R.A Kartini sosok revolusi sebuah kepahlawan untuk wanita yang Bijak dalam memimpin Kota Jepaa.</p>'),
(9, 'wisata', '', '<p style="text-align: justify;">Kabupaten Jepara adalah salah satu kabupaten di Provinsi Jawa Tengah. Ibukotanya adalah Jepara. Kabupaten ini berbatasan dengan Laut Jawa di barat dan utara, Kabupaten Pati dan Kabupaten Kudus di timur, serta Kabupaten Demak di selatan. Wilayah Kabupaten Jepara juga meliputi Kepulauan Karimunjawa, yang berada di Laut Jawa.</p>\r\n<p style="text-align: justify;">Jepara mempunyai keahlian mengukir yang menjadi citra dari jepara. </p>\r\n<p style="text-align: justify;">Jepara kota kecil sejuta makna.</p>\r\n<p style="text-align: justify;">Jepara mempunyai khas membatik dalam ukiran di desa troso.</p>'),
(15, 'budaya', 'Adat', '<p style="text-align: justify;">Perang Obor Upacara tradisional Obor-oboran merupakan salah satu upacara tradisional yang dimiliki oleh masyarakat Kabupaten Jepara, khususnya desa tegalsambi kecamatan Tahunan Kabupaten Jepara yang tiada duanya di Jawa Tengah ini dan mungkin di seluruh Indonesia. Obor pada upacara tradisional ini adalah gulungan atau bendelan 2 (dua) atau 3 (tiga) pelepah kelapa yang sudah kering dan bagian dalamnya diisi dengan daun pisang kering (jawa : Klaras ). Obor yang telah tersedia dinyalakan bersama untuk dimainkan/digunakan sebagai alat untuk saling menyerang ehingga sering terjadi benturan,benturan obor yang dapat mengakibatkan pijaran-pijaran api yang besar, yang akhirnya masyarakat menyebutnya dengan istilah Perang Obor . Upacara Perang Obor yang diadakan setiap tahun sekali, yang jatuh pada hari Senin Phing malam Selasa Pon di bulan Besar (Dzullijah) diadakan atas dasar kepercayaan masyarakat desa tegal sambi terhadap peristiwa atau kejadian pada masa lampau yang terjadi di desa tersebut Pada saat sekarang upacara tradisional Perang Obor dipergunakan untuk sarana Sedekah Bumi sebagai ungkapan rasa syukur kepada Tuhan Yang Maha Esa atas limpahan Rahmat, Hidayah serta taufikNya kepada warga Desa Tegal Sambi, dan event ini diadakan setiap tahun sekali.</p>\r\n<p style="text-align: justify;">Pesta Baratan Salah satu tradisi masyarakat Jepara yang erat kaitannya dengan Ratu Kalinyamat adalah Pesta Baratan. Kata baratan berasal dari sebuah kata Bahasa Arab, yaitu baraah yang berarti keselamatan atau barakah yang berarti keberkahan. Tradisi Pesta Baratan dilaksanakan setiap tanggal 15 Syaban (kalender Komariyah) atau 15 Ruwah (kalender Jawa) yang bertepatan dengan malam nishfu syakban. Kegiatan dipusatkan di Masjid Al Makmur Desa Kriyan Kecamatan Kalinyamatan. Ritualnya sederhana, yaitu setelah shalat maghrib, umat islam desa setempat tidak langsung pulang. Mereka tetap berada di masjid / musholla untuk berdoa bersama. Surat Yasin dibaca tiga kali secara bersama-sama dilanjutkan shalat isya berjamaah. Kemudian memanjatkan doa nishfu syakban dipimpin ulama / kiai setempat, setelah itu makan (bancaan) nasi puli dan melepas arak-arakan. Kata puli berasal dari Bahasa Arab : afwu lii, yang berarti maafkanlah aku. Puli terbuat dari bahan beras dan ketan yang ditumbuk halus dan dimakan dengan kelapa yang dibakar atau tanpa dibakar. Setelah makan nasi puli, masyarakat di desa Kriyan dan beberapa desa di sekitarnya (Margoyoso, Purwogondo, dan Robayan) turun dari masjid / mushalla untuk melakukan arak-arakan. Ada aksi theatrikal yang dilaksanakan seniman setempat, selebihnya diikuti oleh seluruh lapisan masyarakat dewasa maupun anak-anak. Ribuan orang dengan membawa lampion bergerak dari halaman masjid Al Makmur Desa Kriyan dengan mengarak simbol Ratu Kalinyamat dan Sultan Hadirin menuju pusat Kecamatan. Mereka meneriakkan yel-yel ritmis : tong tong ji, tong jeder, pak kaji nabuh jeder, dan sebagian lainnya melantunkan shalawat Nabi. Dari sisi agama, tradisi ini dianggap sebagai ritual penyucian diri bagi umat islam, apalagi pelaksanaannya menjelang puasa bulan Romadlon. Selain itu, tradisi ini menggambarkan semangat dan optimisme dalam menjalani hidup, disamping keteguhan dalam menghadapi berbagai cobaan. Semua itu terangkum dalam doa nishfu syakban yang dipanjatkan.</p>\r\n<p style="text-align: justify;">Jembul Tulakan Dilaksanakan setahun sekali, setiap bulan Apit hari Senin Pahing, sebagai tanda rasa syukur pada Tuhan Yang Maha Esa atas rizki yang dilimpahkan pada penduduk Kademangan Tulakan. Ki Demang Barata mengadakan upacara syukuran yang kemudian dikenal dengan sedekah bumi. Arti kata sedekah bumi adalah sedekah ( amal ) adri hasil bumi yang diwujudkan dengan berbagai macam makanan kecil. Sebagai langkah untuk mengingat laku tapa brata yang dilakukan oleh Nyai Ratu Kalinyamat dalam menuntut keadilan atas kematian suaminya Sunan Hadiri, yang dibunuh oleh Arya Panagsang. Sebelum sedekah bumi pada hari Senin Pahing, didahului manganan dipunden Nyai Ratu Kalinyamat, yaitu bekas pertapaan. Pada hari Jumat Wage sesuai dengan riwayat yang menyebutkan bahwa kedatangan Ratu Kalinyamat untuk bertapa adalah Jumat Wage. Sebagai tanda bukti dan setia murid-murid Ki Demang Barata yang sudah memimpin pedukuhan, masing-masing mengantarkan makanan kecil kerumah Ki Demang. Makanan kecil tersebut diletakkan dalam dua buah ancak dan diatas makanan kecil ditanamkan belahan bambu yang diirat tipis-tipis. Iratan tipis bambu tersebut melambangkan rambut jembul dengan diatur sedemikian rupa. Ancak dari rambut jembul dari iratan bambu tipis tersebut dinamakan Jembul Tulakan. Jembul merupakan perlambangan dari ungkapan yang diucapkan oleh Ratu Kalinyamat waktu menjalani pertapaan yaitu Ora pati-pati wudhar tapaningsun, yen durung keramas getehe lan karmas keset jembule Aryo Panangsang yang dapat berarti tidak akan menyudahi tapa kalau belum keramas dengan darah dan keset rambut Aryo Panangsang. Dalam pelaksanaan Sedekah Bumi Tulakan atau dikenal juga dengan Upacara Jembul Tulakan ini, disuguhkan dua macam Jembul. Jembul yang besar di depan atau sering disbut Jembul Lanang, sedangkan jembul kecil berada di belakang disebut dengan jembul wadon. Khusus Jembul Lanang dihiasi dengan iratan bambu tipis sedangjan Jembul Wadon tidak. Jembul Lanang di dalamnya terdapat bermacam-macam makanan kecil, seperti jadah (gemblong), tape ketan. Apem dan sebagainya, sedangkan Jembul Wadon berisi lauk-pauknya Jumlah jembul disesuaika dengan jumlah pedukuhan yang dipimpin oleh kepala-kepal dukuh atau dalam istilah sekarang adlah Kamituwo. Antara lain,pertama, jembul Krajan yaitu jembul dari penduduk dukuh Krajan,tempat kediman Ki demang sebagai pusat pemerintahan Kademangan. Jembul ini memounyai cirri khas berupa golek yang mengganbarkan seorang tokoh bernama Sayid Usman, seorang Nayoko Projo Ratu Kalinyamat. Kedua, Jembul Ngemplak merupakan wujud dari penghargaan masyarakat untuk Ki Leboh atas perjuanganya membuka perdukuhan Ngemplak, mengingat Ki Leboh adalah kepala dukuh Kedondong yang wilayahnya termasuk Ngemplak. Sebagai identitas Ki Leboh dibuatlah golek dari tokoh yang bernama Mangun Joyo seorang Nayoko Ratu Kalinyamat. Ketiga, jembul Winong adalah penghargaan terhadap Ki Buntari yang telah merintis sebagai kepala dukuh dan membangunnya dengan baik. Sebagai perlambang dari tokoh tersebut dibuat golek yang merupakan barisan prajurit yang gagah perkasa yang mengawal dan mengamankan keberangkatan Ratu Kalinyamat dari kabupaten Jepara sampai selama di pertapaan Siti Wangi-Sonder. Keempat, Jembul Drojo merupakan penghargaan terhadap Ki Purwo atas segala jasanya membuka pedukuhan. Sebagai bentuk dari penghargaanya maka dibuatlah golek yang menggambarkan seorang tokoh yang bernama Mbah Leseh seorang tokoh Kalinyamat. Prosesi dari penampilan jembul ini adalah satu-persatu dengan pertunjukan tarian tayub. Hal ini sebagai pengulangan kembali peristiwa pada waktu para nayoko menghadap Ratu Kalinyamat dan dipertunjukan tarian penghormatan dengan tayup.</p>\r\n<p style="text-align: justify;">Dalam pelaksanaan Sedekah Bumi Tulakan atau dikenal juga dengan Upacara Jembul Tulakan ini, disuguhkan dua macam Jembul. Jembul yang besar di depan atau sering disbut Jembul Lanang, sedangkan jembul kecil berada di belakang disebut dengan jembul wadon. Khusus Jembul Lanang dihiasi dengan iratan bambu tipis sedangjan Jembul Wadon tidak. Jembul Lanang di dalamnya terdapat bermacam-macam makanan kecil, seperti jadah (gemblong), tape ketan. Apem dan sebagainya, sedangkan Jembul Wadon berisi lauk-pauknya Jumlah jembul disesuaika dengan jumlah pedukuhan yang dipimpin oleh kepala-kepal dukuh atau dalam istilah sekarang adlah Kamituwo. Antara lain,pertama, jembul Krajan yaitu jembul dari penduduk dukuh Krajan,tempat kediman Ki demang sebagai pusat pemerintahan Kademangan. Jembul ini memounyai cirri khas berupa golek yang mengganbarkan seorang tokoh bernama Sayid Usman, seorang Nayoko Projo Ratu Kalinyamat. Kedua, Jembul Ngemplak merupakan wujud dari penghargaan masyarakat untuk Ki Leboh atas perjuanganya membuka perdukuhan Ngemplak, mengingat Ki Leboh adalah kepala dukuh Kedondong yang wilayahnya termasuk Ngemplak. Sebagai identitas Ki Leboh dibuatlah golek dari tokoh yang bernama Mangun Joyo seorang Nayoko Ratu Kalinyamat. Ketiga, jembul Winong adalah penghargaan terhadap Ki Buntari yang telah merintis sebagai kepala dukuh dan membangunnya dengan baik. Sebagai perlambang dari tokoh tersebut dibuat golek yang merupakan barisan prajurit yang gagah perkasa yang mengawal dan mengamankan keberangkatan Ratu Kalinyamat dari kabupaten Jepara sampai selama di pertapaan Siti Wangi-Sonder. Keempat, Jembul Drojo merupakan penghargaan terhadap Ki Purwo atas segala jasanya membuka pedukuhan. Sebagai bentuk dari penghargaanya maka dibuatlah golek yang menggambarkan seorang tokoh yang bernama Mbah Leseh seorang tokoh Kalinyamat. Prosesi dari penampilan jembul ini adalah satu-persatu dengan pertunjukan tarian tayub. Hal ini sebagai pengulangan kembali peristiwa pada waktu para nayoko menghadap Ratu Kalinyamat dan dipertunjukan tarian penghormatan dengan tayup.</p>\r\n<p style="text-align: justify;">.</p>'),
(16, 'budaya', 'Tarian Tradisional', '<p style="text-align: justify;">Tari Kridhajati merupakan tarian khas asal kota ukir yaitu Jepara, Jawa Tengah. Tarian yang bisa dipraktikkan satu orang, berkelompok maupun secara massal ini menggambarkan masyarakat Jepara yang adiluhung dalam berkarya seni. Tarian ini dicipta dan dikemas atas petunjuk Bapak Bupati Jepara Drs. Hendro Martojo, MM. Tarian Kridhajati ini ditarikan dalam bentuk figurasi huruf : Hari Jadi Jepara dan dipentaskan setelah upacara hari jadi Jepara.</p>\r\n<p style="text-align: justify;">ika memperhatikan geraknya, tarian ini jelas menggambarkan proses kinerja kerajinan ukir. Mulai dari pencarian kayu di hutan, menggambar obyek di kayu, menatah, hingga diplitur dengan warna-warni yang memukau dan dikemas. Setelah tahap itulah, ukiran yang telah jadi kemudian dipasarkan.</p>'),
(17, 'budaya', 'Rumah Adat JOGLO', '<p style="text-align: justify;">Joglo Jepara adalah Rumah Adat Jepara merupakan salah satu rumah tradisional yang mencerminkan perpaduan akulturasi kebudayaan masyarakat Jepara. Joglo Jepara yang kini di Puri Maerokoco dahulunya adalah Rumah Warga Jepara tepatnya dari Desa Kalipucang Wetan, Pada tahun 1984 pemerintah membeli joglo jepara pada pemiliknya yang bernama Mbah Haji Tohar sebesar Rp. 8.000.000,-. Rumah Adat Jepara memiliki atap genteng yang disebut Atap Wuwungan. Jenis bangunan ini merupakan bangunan tradisional di daerah Jepara dan sampai saat ini masih banyak dijumpai. Ciri khusus arsitektur bangunan ini adalah :\r\n<p style="text-align: justify;">\r\n    Bahan bangunan terbuat dari kayu dengan dinding kayu berukir\r\n    Memiliki 4 buah tiang di tengah bangunan\r\n    Atap dari genting dan khusus kerpus memiliki motif ukiran gambar wayang.</p>\r\n<p style="text-align: justify;">\r\nAdapun konsep falsafah dari bangunan joglo ini adalah:\r\n\r\n    Menghadap ke laut dengan maksud agar berpikiran luas\r\n    Membelakangi gunung dengan maksud agar tidak congkak dan tinggi hati\r\n    Atap berujud pegunungan dengan maksud religius yaitu Tuhan di atas dan berkuasa atas segalanya</p>\r\n<p style="text-align: justify;">    Tiga buah pintu di depan merupakan perwujudan hubungan antara:\r\n\r\n    Manusia dengan Tuhan\r\n    Manusia dengan manusia\r\n    Manusia dengan alam</p>\r\n<p style="text-align: justify;">    Tiga wuwungan atap tidak patah tetapi melengkung yang mempunyai maksud sebagai perwujudan cara hidup yang luwes.</p>'),
(18, 'budaya', 'Kayu Legenda, Kayu Sepuh, Kayu Bertuah ', '<p style="text-align: justify;">Kayu Dewadaru</p>\r\n<p style="text-align: justify;">Kayu dewadaru di karimun jawa merupakan kayu yang paling dituakan atau dikeramatkan,sejarah sunan Nyamplungan yang membawa kayu ini dari ayahnya yaitu Sunan Gunung Muria yang dahulunya berbentuk tongkat alam.Tokoh spritual,metafisika,pedaga?ng,pengusaha,bahkan pejabat banyak berburu jenis kayu dewadaru yang tenggelam sebagai media mistik juga nilai pengobatan medis maupun non medis.</p>\r\n<p style="text-align: justify;">Dewadaru jika dibawa keluar dari kepulauan karimun jawa di perairan laut pulau ini akan mendatangkan angin dan ombak besar sehingga banyak kapal yang tenggelam terommbing-ambing ombak atau angin taufan,karena sifat kayu ini mendatangkan angin dan ombak besar jika dibawa ke tengah laut karimun jawa.Seakan-akan kayu ini tidak mau dibawa keluar dari pulau (masih banyak saksi hidup yang mengalami kejadian ini) Warga pulau karimun jawa maupun warga jepara kota sendiri,bahkan ibu kandung,nenek juga pak lek saya mengalaminya Alhamdulillah selamat karena berhasil menemukan kayu yang diselipkan di kemudi kapal dan dibuang ke laut,akhirnya awan yang gelap kembali terang ,angin dan ombak yang tiba-tiba ganas mulai bersahabat lagi,selamatlah ibu dan nenek saya.</p>\r\n<p style="text-align: justify;">Sejak terakhir kejadian kapal tongkol pecah terhantam badai ombak karena dibawanya kayu dewadaru di kapal,maka para tokoh sesepuh pulau melakukan riyadhoh yang bertujuan meredam efek negatif membawa kayu ini keluar dari pulau.Akhirnya dari tirakat para sesepuh diwejangkan UNTUK PERAHU,KAPAL YANG MEMBAWA KAYU DEWADARU HARUS DILENGKAPI DENGAN PERABOT KAPAL YANG BERNAMA PASAK PAKU KAPAL DARI 3 KAYU YAITU PASAK KAYU KALIMASADA DI DEPAN,DEWADARU DI TENGAH DAN SETIGI DI BELAKANG.Dengan menggunakan kapal berpasak tiga kayu inilah sekarang para nelayan maupun warga selamat membawa kayu dewadaru keluar dari pulau. Sejak riyadhoh tirakat para sesepuh,ke tiga kayu ini mulai terkenal luas sebagai pasangan campuran 3 kayu untuk tongkat,tasbih maupun aksesoris yang merupakan kerajinan khas karimun jawa.</p>\r\n<p style="text-align: justify;">Sumber sesepuh mengatakan kayu dewadaru cocok untuk tasbih sebagai alat bantu wirid lelaku/tirakatan Cocok juga untuk pedagang sebagai piranti mahabbah,penglaris Juga dibakar seperti dupa untuk menarik benda pusaka bagi para ahlinya. Rendaman kayu dewadaru di air sumber bila diminum dengan ijin Allah bisa untuk pengobatan juga penetralisir racun atau bisa hewan berbisa,juga berguna menyembuhkan orang kesurupan. Bahkan limbah atau rendaman kayu ini digunakan untuk tinta wifiq atau rajah bagi ahli supranatural Juga mempunyai fadhilah meningkatkan keberanian nyali atau meningkatkan rasa percaya diri</p>\r\n<p style="text-align: justify;">Energi alaminya terasa saat sering digunakan wirid,dzikir,bangsa khodam menyukai kayu dewadaru sebagai tempat tinggalnya.Jadi jika suatu saat pengguna tasbih kayu dewadaru karimun jawa merasakan adanya khodam yang secara alami menyatu di piranti tasbih kayu ini jangan kaget.Biasanya kayu dewadaru dari pohon tua ratusan tahun yang mempunyai energi lebih disbanding dewadaru yang muda dan kayu deawadaru tua cenderung tenggelam di air mirip setigi untuk kualitas dewadaru terbaik. Karakter kayunya yang keras warna tua dengan serat yang mirip kayu asem,tapi agak rapat</p>\r\n<p style="text-align: justify;">Kayu Setigi</p>\r\n<p style="text-align: justify;">Dalam dunia alternative herbal penawar maupun dalam media mistik supranatural, kayu setigi darat maupun setigi laut sangat dikenal dan banyak digandrungi sejak jaman dulu.Karakter serat kayunya yang keras dan anti hama serta semakin lama dipakai akan semakin indah dan tua dengan kilap dari gesekan jari jemari.Kelangkaan dan keunikan serta fadhilah alaminya membuat setigi menjadi kayu bertuah di urutan kelas atas.Pohon kayu setigi tergolong kayu langka yang di jaman sekarang cukup sulit ditemui.Pertumbuhan pohon setigi cukup lambat dalam kurun waktu 5-10 tahun hanya berdiameter 4-7 cm saja dan tingginyapun tidak seberapa hanya sekitar 1 m.Karakter batang setigi berkelok atau tidak lurus mempunyai serat yang alot atau keras lebih keras dari kayu biasa pada umumnya.Keunikan kayu setigi tenggelam di air walau hanya secuil saja,bahkan kualitas kayu setigi yang tua ratusan tahun dari kayu mati ngurak limbah serbuk gergajinya juga tenggelam di air.Keunikan yang lain adalah mempunyai sifat alami sebagai kayu penyedot bisa hewan atau serangga berbisa (upas-upasan bahasa jawa) dengan cara ditempelkan dibekas sengatan atau gititan luka baru, kulit bekas gigitan akan terasa tersedot sampai bisa racun tadi keluar atau terhisap oleh kayu setigi.PERLU DIKETAHUI BAHWA SETIGI UNTUK SEDOT BISA ADALAH DARI KAYU KERING DAN TUA AKAN LEBIH MAKSIMAL MANFAATNYA.Kenuikan alam yang lain adalah stigi atau setigi,mentigi,cantigi mempunyai aura atau getaran energy metafisika alami mirip benda pusaka tanpa asmaan,isim maupun pengisian khodam. Kayu biasa atau pada umumnya tidak mempunyai energy khowas atau aura seperti stigi yang tergolong kayu bertuah.</p>\r\n<p style="text-align: justify;">Manfaat dari pandangan herbal alternative sesepuh setigi mempunyai manfaat perobatan untuk:</p>\r\n<p style="text-align: justify;">sedot bisa racun ular,sengatan serangga. pereda sakit gigi dengan cara meminum rendaman kayu setigi. mengurangi dan membantu meredakan rheumatic (cocok untuk pijat) dengan cara di gosokkan atau dipijatkan. membantu menetralisir racun dari rendaman airnya yang diminum.</p>\r\n<p style="text-align: justify;">Manfaat dari pandangan metafisika,supranatural kayu setigi Insha Allah mempunyai fadhilah untuk :</p>\r\n<p style="text-align: justify;">Hasil penelitian dengan foto aura,setigi yang dipakai kalung selama 10 menit memunculkan aura orange dan merah menunjukkan kayu mengandung unsur energy kekuatan vitalitas,will power getaranya atau energinya dominan di otak.</p>\r\n<p style="text-align: justify;">1.Media penangkal santet,guna-guna</p>\r\n<p style="text-align: justify;">2.Mediator kekebelan, Keselamatn ,Babur rizki</p>\r\n<p style="text-align: justify;">3.Media isim,asma,pengisian khodam atau penyimpan energy alam</p>\r\n<p style="text-align: justify;">4.Energi pada kayu setigi semakin meningkat untuk media wirid,dzikir,meditasi dll</p>\r\n<p style="text-align: justify;">SETIGI TERBAIK KUALITAS KAYU UNTUK PENGOBATAN MAUPUN MEDIA MISTIKNYA BERASAL DARI PULAU TERPENCIL PULAU LELAKU SESEPUH JAMAN DULU YAITU KARIMUN JAWA KABUPATEN JEPARA SEBELAH UTARA JEPARA KOTA.DI PULAU INILAH PARA LELAKU MUSYAFIR DARI SEJAK JAMAN DULU MAUPUN PELAKU TIRAKAT SUPRANATURAL MELALUKAN LELAKU.PULAU INI DENGAN BABAT TANAH KARIMUN MBAH DANANG DOYO DAN SESEPUH PUTRA SUNAN GUNUNG MURIA SYECH AMIR HASAN.</p>\r\n<p style="text-align: justify;">Aura kualitas kayu dan energy setigi serta keragaman jenis bisa dibandingkan dengan kayu setigi dari daerah lain. Setigi laut adalah pohon setigi yang tumbuh di pesisir pantai,karakter kayunya tahan hama karena menggandung garam,keras dan berwarna coklat muda atau kuning dari jenis setigi laut ada dua yaitu setigi laut coklat dan setigi laut hjenis barek kuning dengan motif garis zebra tiger eye bergerak jika terkena sinar sepeti gambar di atas.</p>\r\n<p style="text-align: justify;">Setigi darat tempat tumbuhnya di daratan biasanya di bukit-bukit yang dekat pantai atau daerah pulau mempunyai warna lebih tua dari setigi laut dengan serat kayu yang lebih keras,dan berdaun kecil tapi lebih lebar dari setigi laut.Jenis setigi darat memang lebih berkarakter dengan kekerasannya yang lebih keras pada kayu umumnya walaupun tak sekeras batu dan mengandung kapur karena daerah tumbuhnya di tanah yang berkapur/mengandung kapur biasanya di lahan tandus area pulau.Adapun jenisnya adalah setigi darat wulung dengan warna kayu coklat tua,seiring usia kayu maka warnanya semakin pekat,satunya lagi adalah jenis setigi darat hitam yang didapatkan dari kayu setigi tua atau pohon tua yang tumbang dan tertimbun tanah,dari proses inilah kayu setigi tertimbun tanah puluhan tahun karena tidak membusuk disebabkan karakter kekerasan dan tahan hama fermentasi alam menghasilkan batang setigi pendem yang hitam walaupuntak semua batang berwarna hitam atau belang coklat tua dan hitam.Primadona dari jenis yang paling langka yaitu setigi darat jenis barek orang jawa menyebut barek abang atau setigi darat barek merah warnanya coklat kemerahan dengan motif garis-garis tiger eye.</p>\r\n<p style="text-align: justify;">Setigi darat dan laut sebenarnya jenis yang sama hanya saja tempat tumbuhnya yang berbeda,dari setigi laut yang tumbuh di area pesisir pantai dan jenis setigi darat yang tumbuh di bukit-bukit atau dataran tinggi.Setigi laut cenderung mempunyai warna lebih terang atau cerah dibanding jenis setigi darat yang mempunyai warna lebih tua dan lebih keras.Kelebihan setigi laut lebih tahan hama dibanding setigi darat,kelebihan setigi darat mempunyai batang yang lebih dinamis dan mengandung kapur pada kayunya.</p>\r\n<p style="text-align: justify;">Kayu Kalimasada</p>\r\n<p style="text-align: justify;">Kayu kalimasada mempunyai warna yang cenderung hitam,kayunya ringan dengan serat atau belang mirip sono keling.Karimun jawa memang pulau mistik yang banyak menyimpan keanekaragaman jenis kayu langka bertuah termasuk kayu kalimasada yang biasa digabungkan dengan setigi maupun dewadaru atau kayu-kayu bertuah lainya.Pohon kalimosodo cenderung lebih cepat tumbuh atau besar mempunyai daun yang lebar dan berbuah orang pulau menyebut pentil kembang kalimosodo.Pohon ini biasa tumbuh didaerah rawa maupun di daratan namun mempunyai karakter kayu yang kering dan agak beserat nggedibel atau kasar.</p>\r\n<p style="text-align: justify;">Dari nama KALIMASADA ATAU KALIMOSODO mepunyai arti kalimah sahadad cocok dengan namanya jenis kayu ini untuk bertasbih,dzikir atau membaca aurad lelaku dapat meningkatkan energi spiritualis seseorang serta mempunyai kelebihan untuk menyimpan energi aurad yang dibaca.Khowas kayu kalimasada yang sejuk beraura ungu atau biru digunakan sebagai campuran atau peyeimbang energy campuran beberapa kayu bertuah seperti campuran setigi,dewadaru yang digabungkan dengan kalimasada. Fadhilah kayu kalimasada dari pandangan surnatural metafisika ;</p>\r\n<p style="text-align: justify;">1 Meningkatkan energi spiritualis seseorang</p>\r\n<p style="text-align: justify;">2. Menyimpan energi wirid , Orang yang temperamental menggunakan kayu ini sebagai pendingin</p>\r\n<p style="text-align: justify;">3. Dipakaikan pada bayi sebagai pelindung (sambetan)</p>\r\n<p style="text-align: justify;">4.Mempunyai energi pengasih, Cocok untuk bisnisman maupun pejabat yang sering bersosialisai dengan masa untuk meningkatkan wibawa,kharisma.Cocok untuk dipakai wanita sebagai dinding dari guna-guna atau pelet</p>\r\n<p style="text-align: justify;">5. Penyeimbang dan memperkuat energy kayu bertuah lain yang dipasangkan</p>\r\n<p style="text-align: justify;">Sebagai alat atau piranti tasbih kayu bertuah mempunyai kelebihan dibanding dengan tasbih kayu atau bahan biasa pada umumnya yaitu yang sering dirasakan meningkatkan daya konsentrasi saat wirid dan tidak cepat lelah saat bersila (tafakur) meningkatkan semangat saat wirid atau dzikir,serta mempunyai kelebihan sebagai kayu penyimpan energy wirid serta peningkat energy spiritual yg di jalani saat lelaku dengan tasbih kayu kalimasada.</p>\r\n<p style="text-align: justify;">KUALITAS WARNA KALIMASADA YANG BAIK ADALAH DARI JENIS POHON BERUSIA DI ATAS 30 TAHUN KARENA YANG MUDA KARAKTERNYA LUNAK DAN CENDERUNG KASAR . KSLIMOSODO YANG TELAH LAMA TUMBANG JUGA BERKUALITAS LEBIH BAIK DIKARENAKAN KANDUNGAN AIR YANG RENDAH TIDAK MUDAH MENYUSUT SAAT DIBUAT KERAJINAN</p>'),
(20, 'wisata', 'Legenda', '<p style="text-align: justify;">Jepara, sebetulnya nama obyek wisata Pantai Kartini lebih dikenal dengan sebutan PEMANDIAN pikiran mereka langsung tertuju pada satu maksud yaitu Pantai Kartini, bukan obyek wisata yang lain. Istilah PEMANDIAN berasal dari kata MANDI yang mengandung pengertian tempat untuk mandi. Letak tempat tersebut tepatnya berada di bagian pantai yang paling barat dan oleh masyarakat dikenal dengan sebutan PONCOL. Biasanya para pengunjung melakukan mandi di tempat ini pada waktu fajar dan sore menjelang senja sekaligus menyaksikan keindahan sunset. lokasi ini masih tetap digunakan untuk mandi para penderita sakit kulit gatal-gatal, &amp; rematik dengan harapan sakitnya segera sembuh. Pantai yang jaraknya tidak begitu jauh dari rumah kediaman (Pendopo Kabupaten) dimana beliau dibesarkan ini memang dulu menjadi daerah tujuan wisata bagi keluarga/kerabat Kabupaten untuk beristirahat dan melepas lelah.</p>\r\n<p style="text-align: justify;">Di pantai ini pula RA Kartini pada masa kecilnya sering bermain-main dan bercanda ria bersama-sama saudaranya. Akhirnya sebagai ungkapan penghargaan dan untuk mengingat kebesaran perjuangan RA Kartini maka pantai tersebut dinamakan PANTAI KARTINI.</p>\r\n<h4 style="text-align: justify;">Sejarah Ajeng Kartini</h4>\r\n<p style="text-align: justify;">Ibu Kartini, Putera Bupati Jepara, R.M. Adipati Ario Sosronigrat, cucu Bupati Demak Pangeran Ario Tjondronagoro. Beliau adalah seorang Bupati yang telah berfikir maju, dan telah memberikan pendidikan barat kepada putera-puteranya dengan mendatangkan seorang guru dari negeri Belanda. Penduduk Jawa dan Madura pada saat itu masih sangat sedikit yang berpendidikan, ternyata pada tahun 1902 hanya terdapat orang Bupati yang pandai menulis dan berbahasa Belanda, mereka itu adalah :</p>\r\n<p style="text-align: justify;">1. Bupati Serang : P.A.A. Ahmad Djajadiningrat</p>\r\n<p style="text-align: justify;">2. Bupati Ngawi : R.M.T. Kusumo Utojo.</p>\r\n<p style="text-align: justify;">3. Bupati Demak : P.A. Adinigrat, Paman Ibu Kartini</p>\r\n<p style="text-align: justify;">4. Bupati Jepara : R.M.A.A. Sosroningrat, Ajah ibu Kartini</p>\r\n<p style="text-align: justify;">Ibu Kartini dilahrikan pada tanggal 21 April 1879, di Majong Kabupaten Jepara. Beliau Putera kelima dari 11 orang bersaudara yang urut-urutannya sebagai berikut:</p>\r\n<p style="text-align: justify;">1. R.M. Sosroningrat</p>\r\n<p style="text-align: justify;">2. P.A. Sosrobusono, Bupati Ngawi</p>\r\n<p style="text-align: justify;">3. R.A. Sosroaditjokro</p>\r\n<p style="text-align: justify;">4. R.M. Sosrokartono.Drs</p>\r\n<p style="text-align: justify;">5. R.A. Kartini</p>\r\n<p style="text-align: justify;">6. R.A. Rukmini</p>\r\n<p style="text-align: justify;">7. R.A. Kardijah, Isteri Bupati Tegal</p>\r\n<p style="text-align: justify;">8. R.A. Kartinah</p>\r\n<p style="text-align: justify;">9. R.A. Sosromuljono</p>\r\n<p style="text-align: justify;">10. R.M. Sumantri Sosrohadikusumo</p>\r\n<p style="text-align: justify;">11. R.M. Sosrorawito</p>\r\n<p style="text-align: justify;">Sebagaimana saudara-saudarnya yang lain Ibu Kartini dimasukkan sekolah Europose Lagere School , sekolah untuk orang-orang Belanda dan orang-orang jawa yang terkemuka / kalangan atas. Beliau bersekolah sampai berusia 12 tahun, dan kemudian keluar karena harus menjalani masa pingitan, yang telah mendaji tradisi, adat istiadat dikalangan tertentu bahwa seorang gadis pada saat datangnya masa kedewasaan / remaja tidak diperkenankan keluar rumah, dalam masa yang telah ditentukan.</p>\r\n<p style="text-align: justify;">Selama dalam pingitan beliau tidak banyak bergaul, karena pada saat itu hubungan kekeluargaan masih sangat terikat dengan adat-istiadat . Maka satu-satunya tempat sebagai pelarian kesepian hatinya dan sebagai kawan yang setia adalah buku.</p>\r\n<p style="text-align: justify;">Buku, buku, membaca, demikian hampir seluruh kerja Ibu Kartini, tentunya disamping tugas-tugas keluarga. Buku demi buku dibacanya. Meskipun mengerti,faham akan isinya atau tidak, beliau ingin terus membacanya. Sekali belum faham diulanginya lagi, kedua belum faham, dibaca yang ketiga kalinya. Setelah berusia 16 tahun beliau dibebaskan dari pingitan. Bersamaan dengan itu pula kakak perempuannya yang tidak sefaham hatinya dengan Ibu Kartini menikah, sehingga dengan demikian Ibu Kartini menjadi saudara perempuan yang tertua. Dan mulai pada waktu itulah beliau mengadakan bebrepa perubahan dalam adat-istiadat pergaulannya dengan adik-adiknya perempuan-tiga bersaudara : Kartini, Rukmini dan Kardinah. Pergaulan menjadi tidak kaku lagi, adik-adiknya tidak perlu bersembah-berjngkok dan sebagainya.</p>\r\n<p style="text-align: justify;">Ibu Kartini dengan cita-citanya memang tidak berdiri sendiri, atau dengan perkataan lain benih kebangkitan dan kemajuan yang berada dalam jiwanya tidak mungkin tumbuh dengan subur tanpa pemerliharaan dan siraman yang seksama.</p>\r\n<p style="text-align: justify;">Disamping buku-buku yang menjadi salah satu unsur penyebab suburnya benih cita-citanya Ibu Kartini, maka kenalan-kenalannya (sahabat-sahabatnya), yang semua orang-orang Eropa banyak pula memberikan dorongan dan bimbingan ibarat anjang-anjang bagi tanaman cita-cita Ibu Kartini. Teman-teman Ibu Kartini:</p>\r\n<p style="text-align: justify;">1. Nyonya Cvink Nestenenk , seorang janda ipar Asisten Reseden Jepara, yang memberi pelajaran menggambar kepada Ibu Kartini bersaudara.</p>\r\n<p style="text-align: justify;">2. Nyonya Cvink Soer, Isteri Asisten residen Jepara. Karena tidak mempunyai anak maka sangat erat hubungannya dengan Ibu Kartini, bagaikan ibunya sendiri.</p>\r\n<p style="text-align: justify;">3. Nona Estella Zeehandelaar Stela - , seorang gadis yang berlairan Sosialis. Perkenalannya dengan perantauan majjalah De Hollanse Lelie.</p>\r\n<p style="text-align: justify;">4. Mr. J.H. Abendanon, Direktur pada departemen Pengajaran (O &amp; E), beliau banyak berusaha untuk kemajuan pendidikan anak gadis.</p>\r\n<p style="text-align: justify;">5. Nyonya Abendanon, Isteri Mr. Abendanon</p>\r\n<p style="text-align: justify;">6. Nona Annie Glaser, seorang Guru yang didatangkan di Jepara atas usaha Mr. Abendanon, yang membantu Ibu Kartini dalam mempersiapkan diri mengambil Hulpakte di Jakarta.</p>\r\n<p style="text-align: justify;">7. Ir. Van Kol, seorang tokoh sosialis belanda, anggota Twede kamer.</p>\r\n<p style="text-align: justify;">8. Nyonya Nellie van Kol, isteri Ir. Van kol</p>\r\n<p style="text-align: justify;">9. Edie Abendone, putera Mr. Abendanon.</p>\r\n<p style="text-align: justify;">10. Prof. Dr. G.K. Anton dan Nyonya, di Jena (Jerman), pernah mengunjungi tanah jawa dan singgah di Jepara.</p>\r\n<p style="text-align: justify;">11. Dr. N. Andriani, ahli bahasa yag dikirimkan oleh Bijbel genootschap kedaerah Posso, Sulteng, dan masih terdapat beberapa kenalan lagi. Dalam mengejar cita-citanya Ibu Kartini banyak mendapat hambatan dari keluarganya, terutama dari kakaknya yang sulung, yang sangat menentangnya, sehingga sering kali timbul perselisihan. Adapun ajahnya dalam keadaan bimbang, beliau sangat mencintai puterinya dan memahami akan kebenaran cita-citanya, akan tetapi beliau masih merasa sangat khawatir akan pandangan bangsanya yang masih kolot. Hanya kakaknya Kartono yang dengan terang-terangan mendukung cita-cita Ibu Kartini. Beliau melanjutkan pelajarannya di Semarang. Dan dari beliaulah Ibu Kartini banyak memperoleh buku-buku yang berharga.</p>\r\n<p style="text-align: justify;">Pada tahun 1902 adiknya Rukmini telah mendahului menikah, yang kemudian mengikuti suaminya. Dengan demikian pecahlah tiga bersaudara, Kartini, Rukmini, Kardinah, dan kesepian hati mereka diutamakan pula dalam beberapa surat-surat beliau yang secit-citanya. Kemudian datanglah pinangan dari Bupati Rembang, Raden Adipati Djojo Adiningrat (yang sebelumnya memang sudah dikenal oleh keluarga Ibu Kartini), dan dengan ikhlas Ibu Kartini menerima pinangan itu, setelah terlebih dahulu menyerahkan kembali bea-siswa yang telah disediakan oleh Pemerintah.</p>\r\n<p style="text-align: justify;">Pada tanggal 8 Nopember 1903 berlangsunglah pernikahan Ibu Kartini dan seterusnya mengikuti suaminya ke Rembang, dan sejak itulah Ibu Kartini hidup berdampingan dengan suaminya dan melaksanakan sebagaian dari cita-citanya menyelenggarakan pendidikan untuk anak-anak perempuan. Pada tanggal 13 September 1904 lahirlah putera yang pertama, dan empat hari kemudian 17 September 1904 Ibu Kartini telah dipanggil oleh Tuhan menghadap kehadiratnya, setelah bergulat dengan cita-citanya selama 12 tahun.</p>'),
(21, 'wisata', 'Kerajaan Tertua Di Jepara', '<p>Kerajaan Kalinyamat merupakan sebuah kerajaan yang berasal terdapat di Jepara, Dahulunya Kalinyamat dan Jepara merupakan sebuah Kadipaten bawahan dari Kerajaan Demak, tetapi karena ketika Kerajaan Demak yang saat itu di pimpin Sunan Prawoto dan Arya Penangsang membunuh Sultan Hadlirin, Maka Wilayah Kalinyamat dan Jepara mendirikan Kerajaan sendiri dengan wilayah kekuasaan Kerajaan Kalinyamat meliputi Jepara, Kudus, Pati, Juwana, Rembang, Mataram. Sedangkan Tanah Pati dan Hutan Mentaok (Mataram) di buat sayembara untuk siapa saja yang berhasil membunuh Arya Penangsang. Tembok bentengnya membentang di beberapa desa, meliputi Purwogondo, Margoyoso, Kriyan, Bakalan, Robayan dan pusat Kraton / Siti Inggil di Kriyan, kerajaan Kalinyamat terdapat di daerah Kalinyamatan.</p>\r\n<p>Kalingga atau Ho-ling (sebutan dari sumber Tiongkok) adalah sebuah kerajaan bercorak Hindu yang muncul di Jawa Tengah sekitar abad ke-6 masehi. Letak pusat kerajaan ini belumlah jelas, kemungkinan berada di suatu tempat antara Kabupaten Pekalongan dan Kabupaten Jepara sekarang. Sumber sejarah kerajaan ini masih belum jelas dan kabur, kebanyakan diperoleh dari sumber catatan Tiongkok, tradisi kisah setempat, dan naskah Carita Parahyangan yang disusun berabad-abad kemudian pada abad ke-16 menyinggung secara singkat mengenai Ratu Shima dan kaitannya dengan Kerajaan Galuh. Kalingga telah ada pada abad ke-6 Masehi dan keberadaannya diketahui dari sumber-sumber Tiongkok. Kerajaan ini pernah diperintah oleh Ratu Shima, yang dikenal memiliki peraturan barang siapa yang mencuri, akan dipotong tangannya.\r\n</p>\r\n<p></p>\r\n<p></p>'),
(26, 'kuliner', 'Kuliner Jepara', '<p>&nbsp;</p>\r\n<p>1. Horog-horog<br />Horok-horok adalah makanan ringan yang terbuat dari tepung pohon aren. Makanan ini tergolong langka, dikarenakan Horok-horok umumnya sangat sulit kita temui kalau di luar Jepara. Horok-horok umumnya dimakan dengan sate kikil, soto, bakso, gulai, dan sayur pecel. Selain itu dapat juga dimakan dengan diberi santan dan sedikit gula pasir, seperti bubur. Bahan pokok Horok-horok adalah tepung yang terbuat dari pohon aren, makanan ini sudah populer semenjak masa peperangan.</p>\r\n<p>Yang unik adalah metode ketika mengambil bubuk dari pohon arennya, biasanya para pembuat horok-horok akan menggunakan sisir. Sehingga horok-horok mempunyai bentuk butiran-butiran kecil menyerupai busa styrofoam yang kenyal dengan rasa sedikit asin.</p>\r\n<p>Untuk memperoleh pohon aren yang akan digunakan untuk membuat Horok-horok, para perajin asal Jepara akan berburu sampai ke luar daerah, seperti ke Rembang, Pati dan Blora. Tepung aren ini, setelah dibersihkan, kemudian dikukus hingga matang. Dan setelah didinginkan, horok-horok akan bertekstur kenyal.</p>\r\n<p>Bagi masyarakat Jepara Horok-horok merupakan sumber karbohidrat masyarakat Jepara sebagai pengganti nasi atau lontong.</p>\r\n<p>2. Moto Belong/Gethuk<br />Moto Belong atau yang bisa disebut juga Moto Blong merupakan salah satu jajan pasar asli khas Jepara. Moto Belong mudah ditemukan di pasar-pasar tradisional di Kabupaten Jepara.</p>\r\n<p>Asal usul makanan tersebut dinamakan Moto Belong adalah diambil dari bahasa Jawa, yaitu Moto artinya mata, sedangkan Belong artinya melotot. Makanan tersebut dinamai Moto Belong karena bentuk makanan tersebut menyerupai bentuk mata yang melotot.</p>\r\n<p>Apabila anda ingin membuat jajanan ini di rumah, cukup siapkan pisang dan singkong. Apabila sudah siap, maka parut singkong tadi lalu peras. Kemudian isi pisang yang sudah matang lalu buat seperti kapsul, jika perlu, bisa juga diberi pewarna makanan agar lebih menarik. Untuk penyajiannya, biasanya dengan cara dipotong/diiris tipis-tipis (sehingga berbentuk menyerupai bola mata) dan dicampur dengan parutan kelapa yang ditambah sedikit gula &amp; garam.</p>\r\n<p>3.Adon-adon Coro<br />Adon-Adon Coro atau sering disebut Jamu Adon-Adon Coro merupakan minuman tradisional khas kota Jepara. Minuman ini berupa jamu yang dicampur dengan rempah-rempah, antara lain pandan, merica bubuk, kayu manis, cengkeh, lengkuas yang disiram dengan santan, jahe gula merah dan air. Minuman ini berasa pedas dan hangat, mirip dengan wedang jahe.</p>\r\n<p>Adon-adon coro bisa ditemui di pelataran sekitar Shopping Centre Jepara, di sebelah utara Alun-Alun Kota Jepara.</p>\r\n<p>4. Blenyik<br />Blenyik atau yang akrab dikenal dengan nama Tempong adalah kumpulan ikan teri kecil yang dibentuk menjadi kepalan bulat seperti bakwan. Karena dicampur dengan garam, rasanya cenderung asin. Namun bisa pula dibuat dengan digoreng dan dicampurkan dengan telur.</p>\r\n<p>Makanan ini biasanya dikonsumsi saat turun hujan sebagai teman makan nasi. Kepalan ikan ini bisa diolah dengan cara ditumis atau dikukus dengan atau tanpa santan.</p>\r\n<p>5. Pindang Serani<br />Apabila sejak tadi yang kita bahas adalah jajanan khas Jepara, maka kali ini bukan jajanan melainkan menu utama makanan. Pindang Serani telah diakui oleh para pecinta kuliner dari penjuru negeri karena mempunyai rasa yang sedap, terutama pada kuahnya yang khas.</p>\r\n<p>Pindang ini bisa dibuat dari berbagai macam jenis ikan, bisa bandeng, nila, mujair, patin maupun jenis ikan yang bisa diolah lainnya dengan cara direbus dan diberi bumbu &lsquo;rahasia&rsquo; serani.</p>\r\n<p>Meskipun tanpa santan, kuah dari Pindang Serani ini tetap beraroma sedap karena bumbu itu tadi. Penyajiannya biasa disandingkan dengan nasi putih hangat bersama sambal dan lalapan.</p>\r\n<p>6. Rondho Royal<br />Monyos atau yang memiliki nama keren Rondho Royal adalah salah satu jajanan (lagi) tradisional dari kota Jepara.</p>\r\n<p>Makanan ringan ini terbuat dari tepung beras yang diisi dengan tape lalu digoreng sehingga ia mempunyai cita rasa yang unik. Asin, asam dan manis dapat anda rasakan sekaligus.</p>\r\n<p style="text-align: justify;">Monyos lebih nikmat apabila disajikan dalam keadaan panas. Anda bisa menjumpai penjual-penjual Rondho Royal di pasar-pasar tradisional Jepara.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `setup_slide`
--

CREATE TABLE IF NOT EXISTS `setup_slide` (
`id_slide` int(11) NOT NULL,
  `judul` varchar(50) NOT NULL,
  `konten` text NOT NULL,
  `gambar` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `setup_slide`
--

INSERT INTO `setup_slide` (`id_slide`, `judul`, `konten`, `gambar`) VALUES
(1, 'Hiburan dan Wisata', '<p>Mari berlibur bersama pasangan ataupun sahabat kalian untuk menikmati hiburan wisata beserta event nya</p>', 'karimun_n.jpg'),
(2, 'AYO KE JEPARA BANYAK WISATA DAN HIBURAN', '<p> Begitu Banyak Kesibukan yang melanda dalam hidup dan kadang tidak punya waktu untuk merefresh otak dengan hiburan atau pun nge trip begitu jauh, jangan khawatir si JEPARA masih banyak tempat yang indah untuk mengisi waktu luang dan hore horean </p>', 'Sumanding.jpg'),
(3, 'Unisnu', '<p>\r\nTAk kalah menarik Kuliah di UNIVERSITAS ISALAM NAHDLATUL ULAMA begitu Angler dan mendidik dalam bidang akhlak dan pendidikan\r\n</p>', 'rektorat.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `user_admin` varchar(20) NOT NULL,
  `pass_admin` varchar(20) NOT NULL,
  `level` varchar(20) NOT NULL,
  `aktif` varchar(20) NOT NULL DEFAULT 'Y',
  `nama` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`user_admin`, `pass_admin`, `level`, `aktif`, `nama`) VALUES
('admin', 'admin', 'admin', 'Y', 'Administrator'),
('coba', 'coba', 'operator', 'N', 'Coaba Namanya'),
('operator', 'operator', 'operator', 'Y', 'Namanya Operator');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bukti`
--

CREATE TABLE IF NOT EXISTS `tbl_bukti` (
`id_bukti` int(11) NOT NULL,
  `id_pesan` int(11) NOT NULL,
  `file` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_bukti`
--

INSERT INTO `tbl_bukti` (`id_bukti`, `id_pesan`, `file`) VALUES
(1, 3, 'apple-8554-12847-4-zoom.jpg'),
(2, 4, 'apple-7049-12847-7-zoom.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_daerah`
--

CREATE TABLE IF NOT EXISTS `tbl_daerah` (
`id_daerah` int(11) NOT NULL,
  `kode` varchar(8) NOT NULL,
  `daerah` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_daerah`
--

INSERT INTO `tbl_daerah` (`id_daerah`, `kode`, `daerah`) VALUES
(1, 'BK1', 'ORKES'),
(3, 'BK2', 'PENGAJIAN'),
(4, 'BK3', 'BAND'),
(5, 'TC1', 'TIKET PERSIJAP'),
(6, 'TR 1', 'KARIMUN JAPARA'),
(7, 'TR 2', 'KELILING JEPARA');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kategori`
--

CREATE TABLE IF NOT EXISTS `tbl_kategori` (
`id_kategori` int(11) NOT NULL,
  `kategori` varchar(30) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_kategori`
--

INSERT INTO `tbl_kategori` (`id_kategori`, `kategori`, `keterangan`) VALUES
(1, 'Paket Perorangan', 'Paket Travel ini dikususkan untuk wisatawan yang ingin berlibur sendiri saja. Namun nanti dalam Tour, Touris akan diserentakkan keberangkatannya dalam satu mobil. Dalam satu mobil tersebut maksimal hanya 4 Touris, disertakan dengan Driver dan Pemandu wisata. '),
(2, 'Paket Grup/Kelompok', 'kedua kalinya'),
(3, 'Paket Keluarga', 'ketiga kalinya'),
(4, 'Paket Couple', 'Paket untuk pasanngan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paket`
--

CREATE TABLE IF NOT EXISTS `tbl_paket` (
`id_paket` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `nama_paket` varchar(50) NOT NULL,
  `harga_paket` int(11) NOT NULL,
  `ket_paket` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_paket`
--

INSERT INTO `tbl_paket` (`id_paket`, `id_kategori`, `nama_paket`, `harga_paket`, `ket_paket`) VALUES
(1, 1, 'Orkes', 5000000, 'VIP'),
(2, 1, 'Pengajian', 6000000, 'Paket ini untuk tour perorangan. Dalam tour akan diserentakkan dengan turis lain yang juga memilih paket yang sama. Banyak orang yang di serentakkan berkisar 3-5 orang.'),
(3, 1, 'Band', 4000000, 'VIP'),
(4, 4, 'ticket persijap', 500000, 'VIP'),
(5, 4, 'TOUR KARIMUN', 1200000, 'VIP'),
(6, 4, 'TOUR KELILING JEPARA', 1000000, 'VIP'),
(8, 1, 'orkes camelia', 9000000, 'Kategory Musik Dangdut yang enak dan enak di tonton untuk kalangan anak muda ,dan orang dewasa.');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pesan`
--

CREATE TABLE IF NOT EXISTS `tbl_pesan` (
`id_pesan` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_paket` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `tgl_pesan` date NOT NULL,
  `tgl_tour` date NOT NULL,
  `status` char(2) NOT NULL DEFAULT 'S1'
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_pesan`
--

INSERT INTO `tbl_pesan` (`id_pesan`, `id_user`, `id_paket`, `id_hotel`, `tgl_pesan`, `tgl_tour`, `status`) VALUES
(2, 6, 4, 7, '2014-05-04', '2014-05-24', 'S3'),
(5, 2, 0, 0, '2016-10-29', '0000-00-00', 'S1'),
(7, 2, 2, 0, '2016-11-01', '2016-11-03', 'S3'),
(8, 8, 1, 0, '2016-11-10', '2016-11-26', 'S1'),
(10, 7, 1, 0, '2016-11-10', '2016-11-26', 'S1'),
(12, 9, 1, 0, '2016-11-11', '2016-11-19', 'S1'),
(13, 9, 0, 0, '2016-11-11', '2006-01-02', 'S3'),
(14, 9, 1, 0, '2016-11-11', '2016-11-19', 'S3'),
(15, 9, 0, 0, '2016-11-11', '2016-11-19', 'S3'),
(16, 9, 2, 0, '2016-11-16', '2016-11-26', 'S1'),
(17, 9, 1, 0, '2016-11-16', '2016-11-26', 'S3'),
(18, 9, 1, 0, '2016-11-16', '2016-11-19', 'S1'),
(19, 8, 1, 0, '2016-11-16', '2016-11-26', 'S1'),
(20, 8, 5, 0, '2016-11-16', '2016-11-19', 'S1'),
(21, 8, 2, 0, '2016-11-16', '2016-11-21', 'S1'),
(22, 8, 3, 0, '2016-11-16', '2016-11-22', 'S1'),
(23, 8, 4, 0, '2016-11-16', '2016-11-23', 'S1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
`id_user` int(11) NOT NULL,
  `nama_user` varchar(30) NOT NULL,
  `email_user` varchar(50) NOT NULL,
  `tipe_id` varchar(20) NOT NULL,
  `no_id` varchar(30) NOT NULL,
  `no_hp` varchar(14) NOT NULL,
  `no_rek` varchar(50) NOT NULL,
  `nama_rek` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(12) NOT NULL,
  `tgl_lahir` varchar(30) NOT NULL,
  `jekel` varchar(1) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `nama_user`, `email_user`, `tipe_id`, `no_id`, `no_hp`, `no_rek`, `nama_rek`, `username`, `password`, `tgl_lahir`, `jekel`, `alamat`) VALUES
(8, 'Andi', 'andi@gmail.com', 'Kartu Pelajar', '3737', '00000000000000', '', '', 'andi12', 'walkman', '01 Jun 1995', 'L', '<p>Jl.taman siswa km 5 rt8 rw 2 kecamatan bate</p>'),
(9, 'andalan', 'anda@ymail.com', 'KTP', '', '08988360123', '099908281762', 'andalan', 'anda', '12345', '11 Jan 1994', 'P', '<p>jl.taman serba bisa</p>');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `komentar`
--
ALTER TABLE `komentar`
 ADD PRIMARY KEY (`id_komentar`);

--
-- Indexes for table `setup_about`
--
ALTER TABLE `setup_about`
 ADD PRIMARY KEY (`id_about`);

--
-- Indexes for table `setup_dasboard`
--
ALTER TABLE `setup_dasboard`
 ADD PRIMARY KEY (`id_dasboard`);

--
-- Indexes for table `setup_jepara`
--
ALTER TABLE `setup_jepara`
 ADD PRIMARY KEY (`id_jepara`);

--
-- Indexes for table `setup_slide`
--
ALTER TABLE `setup_slide`
 ADD PRIMARY KEY (`id_slide`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
 ADD PRIMARY KEY (`user_admin`);

--
-- Indexes for table `tbl_bukti`
--
ALTER TABLE `tbl_bukti`
 ADD PRIMARY KEY (`id_bukti`);

--
-- Indexes for table `tbl_daerah`
--
ALTER TABLE `tbl_daerah`
 ADD PRIMARY KEY (`id_daerah`);

--
-- Indexes for table `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
 ADD PRIMARY KEY (`id_kategori`), ADD KEY `id_kat` (`id_kategori`);

--
-- Indexes for table `tbl_paket`
--
ALTER TABLE `tbl_paket`
 ADD PRIMARY KEY (`id_paket`);

--
-- Indexes for table `tbl_pesan`
--
ALTER TABLE `tbl_pesan`
 ADD PRIMARY KEY (`id_pesan`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
 ADD PRIMARY KEY (`id_user`), ADD KEY `id_user` (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `komentar`
--
ALTER TABLE `komentar`
MODIFY `id_komentar` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `setup_about`
--
ALTER TABLE `setup_about`
MODIFY `id_about` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `setup_dasboard`
--
ALTER TABLE `setup_dasboard`
MODIFY `id_dasboard` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `setup_jepara`
--
ALTER TABLE `setup_jepara`
MODIFY `id_jepara` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `setup_slide`
--
ALTER TABLE `setup_slide`
MODIFY `id_slide` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_bukti`
--
ALTER TABLE `tbl_bukti`
MODIFY `id_bukti` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_daerah`
--
ALTER TABLE `tbl_daerah`
MODIFY `id_daerah` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_paket`
--
ALTER TABLE `tbl_paket`
MODIFY `id_paket` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_pesan`
--
ALTER TABLE `tbl_pesan`
MODIFY `id_pesan` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
