<!DOCTYPE html>
<html>
<head>
<meta name="description" content="Biodata"/>
<meta name="Keywords" content="Biodata"/>
<meta name="authors" content="mAHBUB"/>
<meta charset="UTF-8"/>
<title>Biodata</title>
<link rel="stylesheet" href="css/stylebb.css"/>
<body class="metro" style="background-color: #7B91A2">
</head>
<body>
<form action="#" style="width: 1000px"class="posisi";>
<table style="width: 950px;">
<tr>

<tr>
<td colspan="4" style="text-align: center; background-color: gold;color: red"><b>Informasi Umum</b></td>
</tr>
<tr>
<td>Nomor HP</td>
<td>:</td>
<td>+6285641974114</td>
</tr>
<tr>
<td>E-mail</td>
<td>:</td>
<td><a href="mailto:coolbrr@yahoo.com" style="text-decoration: none;color: white";>coolbrr@yahoo.com</a></td>
</tr>
<tr>
<td>Hobi</td>
<td>:</td>
<td>Coding, Traveling, Main Game, Baca Manga, Nonton Anime</td>
</tr>
<td colspan="3" align="right">
<a href="Tugas.html" style="text-decoration: none;"</a><input type="button" onclick="history.back()" value="Kembali"/>
</td>
</table>
<br>
<table style="width: 750px;">


</table>
</form>
</body>
</html>
