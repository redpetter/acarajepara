<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="Biodata"/>
<meta name="Keywords" content="Biodata"/>
<meta name="authors" content="Mahbub"/>
<meta charset="UTF-8"/>
	 
	<link href="css/metro-bootstrap.css" rel="stylesheet">
    <link href="css/metro-bootstrap-responsive.css" rel="stylesheet">
    <link href="css/iconFont.css" rel="stylesheet">
	<link href="css/docs.css" rel="stylesheet">
	<link rel="stylesheet" href="css/styleb.css"/>

    <!-- Load JavaScript Libraries -->
    <script src="js/jquery/jquery.min.js"></script>
    <script src="js/jquery/jquery.widget.min.js"></script>
    <script src="js/jquery/jquery.mousewheel.js"></script>

    <!-- Metro UI CSS JavaScript plugins -->
    <script src="js/load-metro.js"></script>
	<script src="js/docs.js"></script>
    
	<title>Biodata Kelompok RPL 2</title>
	<body class="metro" style="background-color: #F8A133">
<!-- --------------------------------------------------Awal Header-------------------------------------------------- -->
	<nav class="navigation-bar">
        <nav class="navigation-bar-content container">
        	<a href="../" class="element"><span class="icon-home"></span> BERANDA &trade;</a>
            <span class="element-divider"></span>
			<a class="element1 pull-menu" href="#"></a>
			<ul class="element-menu">
				<li>
					<a class="dropdown-toggle" href="masuk.html"> KEMBALI</a>        </li>        
    	</nav>
  	</nav>
<!-----------------------------------END--------------------------->	    
</head>
<body>
<form action="#" style="width: 1000px"class="posisi";>
<fieldset class="h"/>
<table style="width: 980px;">
<tr>
<td rowspan="15" width="250px">
<img src="masuk/logo_0.png" width="250px" height="420px"/>
</td>
</tr>
<tr>
<td><b>Nama Lengkap</b></td>
<td>:</td>
<td>Muhammad Khiorul Fahmi</td>
</tr>
<tr>
<td><b>Nama Panggilan</b></td>
<td>:</td>
<td>Fahmi</td>
</tr>
<tr>
<td><b>Tempat, Tanggal Lahir</b></td>
<td>:</td>
<td>Jepara, 28 Maret 1995</td>
</tr>
<tr>
<td><b>Umur</b></td>
<td>:</td>
<td>21 Tahun</td>
</tr>
<tr>
<td><b>Jenis Kelamin</b></td>
<td>:</td>
<td>Laki - Laki</td>
</tr>
<tr>
<td><b>Gol. Darah</b></td>
<td>:</td>
<td>O</td>
</tr>
<tr>
<td><b>Agama</b></td>
<td>:</td>
<td>Islam</td>
</tr>
<tr>
<td><b>Alamat</b></td>
<td>:</td>
<td>Jln. Soekarno Hatta KM 03</td>
</tr>
<tr>
<td><b>Status</b></td>
<td>:</td>
<td>Belum Menikah</td>
</tr>
<tr>
<td><b>Pekerjaan</b></td>
<td>:</td>
<td>Mahasiswa</td>
</tr>
<tr>
<td><b>Kewarganegaraan</b></td>
<td>:</td>
<td>Indonesia</td>
</tr>
<tr>
<td><b>Riwayat</b></td>
<td>:</td>
<td colspan="1" align="left">
Ingin Tahu Riwayatku ? <a href="Detailfahmi.php"style="text-decoration: none;" target="_parent"><input
type="button"value="Cari tahu ? "/></a>
</td>
</tr>
</table>
</fieldset>
</form>
</body>
</html>