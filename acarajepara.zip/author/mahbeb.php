<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="css/metro-bootstrap.css" rel="stylesheet">
    <link href="css/metro-bootstrap-responsive.css" rel="stylesheet">
    <link href="css/iconFont.css" rel="stylesheet">
	<link href="css/docs.css" rel="stylesheet">
	 <link rel="stylesheet" type="text/css" href="css/tables.css" />

    <!-- Load JavaScript Libraries -->
    <script src="js/jquery/jquery.min.js"></script>
    <script src="js/jquery/jquery.widget.min.js"></script>
    <script src="js/jquery/jquery.mousewheel.js"></script>

    <!-- Metro UI CSS JavaScript plugins -->
    <script src="js/load-metro.js"></script>
	<script src="js/docs.js"></script>
    
    <style>
	</style>
	<title>Biodata Kelompok RPL 2</title>
	<body class="metro" style="background-color: #7B91A2">
<!-- --------------------------------------------------Awal Header-------------------------------------------------- -->
	<nav class="navigation-bar">
        <nav class="navigation-bar-content container">
        	<a href="../" class="element"><span class="icon-home"></span> BERANDA &trade;</a>
            <span class="element-divider"></span>
			<a class="element1 pull-menu" href="#"></a>
			<ul class="element-menu">
				<li>
					<a class="dropdown-toggle" href="masuk.html"> KEMBALI</a>        </li>        
    	</nav>
  	</nav>
<!-----------------------------------END--------------------------->
	            </div>
        </div>
    </div>
	
	<table cellspacing='0'>
  <thead>
    <tr>
      <th>NIM</th>    
	<th>Nama</th>
	  <th>Fakultas</th>
	  <th>Semester</th>
	  <th>Kampus</th>
	  <th>Contact Person</th>
     </tr>
  </thead>
  <tbody>
    <tr>
      <td>1412400000284  </td>
	  <td>MUHAMMAD FATHUL MAHBUB</td>
	  <td>SAINS DAN TEKNOLOGI </td>
	  <td> 5 </td>
	  <td>UNIVERSITAS ISLAM NAHDLATUL ULAMA </td>
	  <td> linbub007@gmail.com </td>
        
    <footer class="dark" data-load="bawahan.html"></footer>
</body>
</html>