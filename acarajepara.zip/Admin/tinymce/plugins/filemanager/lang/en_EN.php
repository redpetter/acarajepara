<?php
define('lang_Select','Select');
define('lang_Erase','Erase');
define('lang_Open','Open');
define('lang_Confirm_del','Are you sure you want to delete this file?');
define('lang_All','All');
define('lang_Files','Files');
define('lang_Images','Images');
define('lang_Archives','Archives');
define('lang_Error_Upload','The uploaded file exceeds the max size allowed.');
define('lang_Error_extension','File extension is not allowed.');
define('lang_Upload_file','Upload');
define('lang_Filter','Filter');
define('lang_Videos','Videos');
define('lang_Music','Music');
define('lang_New_Folder','New Folder');
define('lang_Folder_Created','Folder correctly created');
define('lang_Existing_Folder','Existing folder');
define('lang_Confirm_Folder_del','Are you sure to delete the folder and all the elements in it?');
define('lang_Return_Files_List','Return to files list');
define('lang_Preview','Preview');
define('lang_Download','Download');
define('lang_Insert_Folder_Name','Insert folder name:');
define('lang_Root','root');
?>
